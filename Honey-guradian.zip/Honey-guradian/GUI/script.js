const binaryRain = document.querySelector('.binary-rain');
const chars = "01";

document.getElementById('system-design-btn').addEventListener('click', function() {
  const logo = document.querySelector('.overlay-logo');
  logo.classList.add('fullscreen'); // Triggers the fullscreen animation

  setTimeout(() => {
    window.location.href = 'System Design.html'; // Redirect after the animation
  }, 2000); // Match the duration of the CSS animation
});


function generateRain() {
  const span = document.createElement('span');
  const randomLeft = Math.random() * 100 + '%';
  const randomSize = Math.random() * 10 + 10 + 'px';
  const randomDuration = Math.random() * 10 + 10 + 's';

  span.style.left = randomLeft;
  span.style.fontSize = randomSize;
  span.style.animationDuration = randomDuration;
  span.textContent = chars[Math.floor(Math.random() * chars.length)];
  binaryRain.appendChild(span);

  setTimeout(generateRain, 300); // Increased delay to reduce density
}

generateRain();

