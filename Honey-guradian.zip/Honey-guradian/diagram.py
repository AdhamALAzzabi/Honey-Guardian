from diagrams import Diagram, Cluster, Edge
from diagrams.onprem.container import Docker
from diagrams.onprem.inmemory import Redis
from diagrams.generic.blank import Blank

# Custom attributes for improved clarity
graph_attr = {
    "fontsize": "12",
    "compound": "true",  # Allow edges between clusters
    "pad": "2.0",        # Global padding around the graph
}

node_attr = {
    "fontsize": "12",
    "fontname": "Sans-Serif",
    "margin": "0.6,0.6"  # Margin around nodes
}

edge_attr = {
    "fontsize": "12",
    "fontname": "Sans-Serif",
    "penwidth": "2"  # Thicker lines for clarity
}

# Define custom edge styles for clarity
edge_style_logs = {"color": "blue", "style": "dashed", "dir": "forward", "arrowhead": "open"}
edge_style_data = {"color": "red", "style": "solid", "dir": "forward", "arrowhead": "open"}
edge_style_management = {"color": "green", "style": "dotted", "dir": "forward", "arrowhead": "open"}

with Diagram("Honey-Guardian Detailed System Design", show=False, direction="TB", graph_attr=graph_attr, node_attr=node_attr, edge_attr=edge_attr):
    with Cluster("Honeypot Nodes"):
        honeypots = [
            Docker("Cowrie\nSSH/Telnet Honeypot"),
            Docker("Dionaea\nNetwork Services Honeypot"),
            Docker("HoneyThing\nIoT Honeypot"),
            Docker("Conpot\nICS/SCADA Honeypot"),
            Docker("Glastopf\nWeb Application Honeypot")
        ]

    with Cluster("Data Collection & Logging"):
        logger = Blank("Logstash")
        breadcrumbs = Redis("Breadcrumbs\nFake Credentials")

    with Cluster("Analysis & Visualization"):
        kibana = Blank("Elastic Kibana")

    # Placeholder for the future GUI component
    with Cluster("User Interface"):
        gui = Blank("Future GUI")

    management = Blank("Management & Orchestration")

    # Connect honeypots to logger with labeled edges
    for honeypot in honeypots:
        honeypot >> Edge(**edge_style_logs, label="Logs") >> logger

    # Connect logger to Kibana with data edge style
    logger >> Edge(**edge_style_data, label="Data") >> kibana

    # Management connections
    management >> Edge(**edge_style_management, label="Configuration", constraint="false") >> kibana
    management >> Edge(**edge_style_management, label="Management", constraint="false") >> honeypots
    management >> Edge(**edge_style_management, label="UI Management", constraint="false") >> gui
    breadcrumbs - Edge(**edge_style_management, label="Credentials") >> honeypots

# Adjust the diagram path as needed for your environment
diagram_path = "/path/to/your/diagram.png"
